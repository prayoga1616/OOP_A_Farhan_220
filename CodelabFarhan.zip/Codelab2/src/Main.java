public class Main {// Main.java
    public static class Main {
        public static void main(String[] args) {
            // Membuat dua objek BankAccount
            Codelab2.BankAccount rekening1 = new Codelab2.BankAccount("NIM Anda", "Nama Anda", 1000.00);
            Codelab2.BankAccount rekening2 = new Codelab2.BankAccount("NIM Teman", "Nama Teman", 500.00);

            // Menampilkan informasi rekening
            System.out.println("Informasi Rekening 1:");
            rekening1.tampilkanInfo();

            System.out.println("Informasi Rekening 2:");
            rekening2.tampilkanInfo();

            // Melakukan beberapa transaksi pada rekening1
            rekening1.setorUang(200.00);
            rekening1.tarikUang(150.00);
            rekening1.tarikUang(1200.00); // Mencoba menarik lebih dari saldo

            // Melakukan beberapa transaksi pada rekening2
            rekening2.setorUang(300.00);
            rekening2.tarikUang(100.00);
            rekening2.tarikUang(600.00); // Mencoba menarik lebih dari saldo
        }

