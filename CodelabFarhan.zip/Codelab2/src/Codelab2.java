public class Codelab2 { // Codelab2.java
    public class BankAccount {
        // Atribut
        private String nomorRekening;
        private String namaPemilik;
        private double saldo;

        // Konstruktor
        public BankAccount(String nomorRekening, String namaPemilik, double saldo) {
            this.nomorRekening = nomorRekening;
            this.namaPemilik = namaPemilik;
            this.saldo = saldo;
        }

        // Metode untuk menampilkan informasi rekening
        public void tampilkanInfo() {
            System.out.println("Nomor Rekening: " + nomorRekening);
            System.out.println("Nama Pemilik: " + namaPemilik);
            System.out.println("Saldo: Rp" + saldo);
            System.out.println();
        }

        // Metode untuk menyetor uang
        public void setorUang(double jumlah) {
            if (jumlah > 0) {
                saldo += jumlah;
                System.out.println("Disetor: Rp" + jumlah);
                System.out.println("Saldo Baru: Rp" + saldo);
            } else {
                System.out.println("Jumlah setoran harus positif.");
            }
            System.out.println();
        }

        // Metode untuk menarik uang
        public void tarikUang(double jumlah) {
            if (jumlah > 0 && jumlah <= saldo) {
                saldo -= jumlah;
                System.out.println("Ditarik: Rp" + jumlah);
                System.out.println("Saldo Baru: Rp" + saldo);
            } else if (jumlah > saldo) {
                System.out.println("Saldo tidak cukup untuk penarikan.");
            } else {
                System.out.println("Jumlah penarikan harus positif.");
            }
            System.out.println();
        }
    }

}
